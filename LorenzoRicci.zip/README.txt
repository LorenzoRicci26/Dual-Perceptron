La classe KernelFunctions implementa i 3 metodi kernel: Linear, Polynomial, RBF

La classe MyDualPerceptron implementa l'algoritmo Dual Perceptron 

La classe Main implementa la sequenza di codice per la corretta esecuzione dell'elaborato.

Per runnare il programma eseguire la classe Main.py, successivamente verrà richiesto un numero per il tipo di data set che si vuole utilizzare. Una volta scelto ne verrà chiesto un altro per scegliere la tipologia ti kernel. Infine si aspetta la fine dell'exe e verrà riportata l'accuracy del problema e il tempo impiegato.